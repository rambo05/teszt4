﻿using Org.BouncyCastle.Tls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static Adatbazis db = new Adatbazis();
        static List<Dolgozo> dolgozok = new List<Dolgozo>();

        static void Main(string[] args)
        {
            dolgozok = db.getAllDolgozo();
            feladat01();
            feladat02();
            feladat03();
            feladat04();
            Console.WriteLine("Program vége");
            Console.ReadLine();
        }

        private static void feladat04()
        {
            Console.WriteLine("4. feladat:");
            foreach (Dolgozo item in dolgozok.FindAll(a => a.reszleg.Equals("asztalosműhely")))
            {
                Console.WriteLine($"\t{item.nev}");
            }
        }

        private static void feladat03()
        {
            Console.WriteLine("3. feladat:");
            foreach (var item in dolgozok.GroupBy(a => a.reszleg).Select(b => new { reszleg = b.Key, letszam = b.Count() })) 
            {
                Console.WriteLine(  $"\t{item.reszleg} - {item.letszam} fő");
            }
        }

        private static void feladat02()
        {
            Console.WriteLine( "2. feladat:");
            Dolgozo legjobbanKereso = dolgozok.Find(a => a.ber == dolgozok.Max(b => b.ber));
            Console.WriteLine($"\t{legjobbanKereso.nev} keres legtöbbet ({legjobbanKereso.ber} Ft)");
        }

        private static void feladat01()
        {
            Console.WriteLine( $"1. feladat: a dolgozók száma: {dolgozok.Count} fő" );
        }
    }
}
