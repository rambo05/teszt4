document.addEventListener('DOMContentLoaded', function () {
    const nevInput = document.getElementById('nev');
    const reszlegInput = document.getElementById('reszleg');
    const berInput = document.getElementById('ber');
    const nemeInput = document.getElementById('neme');
    const belepesevInput = document.getElementById('belepesev');
    const hozzaadGomb = document.getElementById('hozzaad');
    const megjelenitGomb = document.getElementById('megjelenit');
    const dolgozokTabla = document.getElementById('dolgozokTabla');
    const apiUrl = "http://localhost/api/index.php?dolgozok";

    megjelenitGomb.addEventListener('click', getAllDolgozo);
    function dolgozoSor(dolgozo) {
        let tr = `<tr>
            <td>${dolgozo.nev}</td>
            <td>${dolgozo.reszleg}</td>
            <td>${dolgozo.ber}</td>
            <td>${dolgozo.neme}</td>
            <td>${dolgozo.belepesev}</td>
            </tr>`;
        return tr;
    }
    async function getAllDolgozo() {
        console.log("get all dolgozo");
        var response = await fetch(apiUrl);
        var dolgozok = await response.json();
        dolgozokTablaFrissit(dolgozok);

    }
    function dolgozokTablaFrissit(osszesDolgozo) {
        console.log("dolgozok tabla frissit");
        dolgozokTabla.innerHTML = "";
        var tabla = `<table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Név</th>
                <th scope="col">Részleg</th>
                <th scope="col">Neme</th>
                <th scope="col">Belépés éve</th>
                <th scope="col">Bér</th>
            </tr>
        </thead>
        <tbody>`;
        osszesDolgozo.forEach(dolgozo => {
            tabla += dolgozoSor(dolgozo);
        });
        dolgozokTabla.innerHTML = tabla + "</tbody></table>";
    }

});
